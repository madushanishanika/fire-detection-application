package com.example.firedetectionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TemperatureAndHumidityRisk extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature_and_humidity_risk);
    }
}
