package com.example.firedetectionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NoOfUsers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_of_users);
    }
}
